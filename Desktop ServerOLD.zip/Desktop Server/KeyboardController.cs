﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//STEP 1
using WindowsInput;


namespace Desktop_Server
{
    class KeyboardController
    {

        public static void PerformMovement(float x, float y)
        {
            if(y<0)
            {
          InputSimulator.SimulateKeyPress(VirtualKeyCode.UP);
            }
            else if(y>0)
            {
          InputSimulator.SimulateKeyPress(VirtualKeyCode.DOWN);
            }

            if(x > 0)
            {
                InputSimulator.SimulateKeyPress(VirtualKeyCode.RIGHT);
            }
            else if(x<0)
            {
                InputSimulator.SimulateKeyPress(VirtualKeyCode.LEFT);
            }

        }

        public static void ProcessSpeech(string text)
        {
            if(text == "save")
            {
                InputSimulator.SimulateModifiedKeyStroke(VirtualKeyCode.CONTROL, new[] { VirtualKeyCode.VK_S});
            }
            else if(text == "previous")
            {
                InputSimulator.SimulateKeyPress(VirtualKeyCode.BACK);
            }

            else if(text == "next")
            {
                InputSimulator.SimulateKeyPress(VirtualKeyCode.NEXT);
            }

            else if(text == "exit")
            {
                InputSimulator.SimulateKeyPress(VirtualKeyCode.ESCAPE);
                InputSimulator.SimulateModifiedKeyStroke(VirtualKeyCode.CONTROL, new[] { VirtualKeyCode.F4 });
            }

            else if(text == "Return")
            {
                InputSimulator.SimulateKeyPress(VirtualKeyCode.RETURN);
            }

            else
            {
                string[] parts = text.Split(new char[] {' '});
                
                if(parts[0].ToLower() == "action" )
                {
                    if (parts[1].ToLower() == "save")
                    {
                        InputSimulator.SimulateModifiedKeyStroke(VirtualKeyCode.CONTROL, new[] { VirtualKeyCode.VK_S });
                    }
                    else if (parts[1].ToLower() == "previous")
                    {
                        InputSimulator.SimulateKeyPress(VirtualKeyCode.BACK);
                    }

                    else if (parts[1].ToLower() == "next")
                    {
                        InputSimulator.SimulateKeyPress(VirtualKeyCode.NEXT);
                    }

                    else if (parts[1].ToLower() == "exit")
                    {
                        InputSimulator.SimulateKeyPress(VirtualKeyCode.ESCAPE);
                        InputSimulator.SimulateModifiedKeyStroke(VirtualKeyCode.CONTROL, new[] { VirtualKeyCode.F4 });
                    }      
                }

                else if(parts[0].ToLower() == "enter")
                {
                    String input = String.Join(" ", parts, 1, parts.Length-1);
                    InputSimulator.SimulateTextEntry(input);
                }

            }

        }

        public static void simulateButton(VirtualKeyCode key, String action)
        {
            if (action == "DOWN")
            {
                InputSimulator.SimulateKeyDown(key);
            }

            else if (action == "UP")
            {
                InputSimulator.SimulateKeyUp(key);                
            }
        }
    }
}
